"""
Pools of fragments used to assemble varied warmup emails so every message
isn't identical boilerplate (which itself looks suspicious to spam filters).
Edit freely — more variety here is better.
"""

SUBJECTS = [
    "Quick question",
    "Following up",
    "Checking in",
    "Notes from earlier",
    "Re: project update",
    "Thoughts on this",
    "Scheduling for next week",
    "Quick update",
    "One more thing",
    "Draft for review",
    "Status check",
    "Touching base",
]

OPENERS = [
    "Hey, hope you're doing well.",
    "Hi, quick note.",
    "Morning — wanted to follow up.",
    "Hope your week is going smoothly.",
    "Just circling back on this.",
    "Hi there,",
]

BODY_LINES = [
    "Wanted to check if you had a chance to look at this yet.",
    "Let me know if you need anything else from my side.",
    "I'll follow up again later this week if I don't hear back.",
    "No rush on this, just wanted it on your radar.",
    "Happy to hop on a call if that's easier.",
    "I've attached nothing for now — just a heads up.",
    "This can wait until next week if you're swamped.",
    "Let me know your thoughts whenever you get a chance.",
    "Should be a quick one to close out.",
    "Appreciate you taking a look.",
]

CLOSERS = [
    "Thanks,",
    "Best,",
    "Cheers,",
    "Talk soon,",
    "Appreciate it,",
]

REPLY_LINES = [
    "Thanks for this — looks good to me.",
    "Got it, appreciate the update.",
    "Sounds good, let's go with that.",
    "Makes sense, thanks for clarifying.",
    "Perfect, that works on my end.",
    "Noted, thank you.",
]
