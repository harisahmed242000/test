# Email Warmer

Slowly ramps sending volume across a pool of mailboxes **you own**, and has
the recipient side read/reply/rescue-from-spam, to build sender reputation
before a domain or account is used for real outreach.

## Setup on your VPS

```bash
# 1. Get the files onto the box, e.g.
scp -r email_warmer user@your-vps:/opt/email_warmer

ssh user@your-vps
cd /opt/email_warmer

# 2. Python env
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# 3. Config
cp config.example.yaml config.yaml
nano config.yaml     # fill in your real accounts + app passwords
```

### Mailgun as sender + Gmail as receiver

Mailgun is send-only SMTP — no mailbox, no IMAP — so it can't do the
reading/replying/spam-rescue half of warming. The config supports mixing
account types for exactly this:

- Mailgun account → `role: sender`, only `smtp_*` fields filled in.
- Gmail account(s) → `role: receiver` (or `both` if you also want it to
  send replies), only `imap_*` fields required, `smtp_*` optional.

The script only sends from `sender`/`both` accounts and only checks
inboxes on `receiver`/`both` accounts. A `receiver` without `smtp_*`
fields will still get marked read and rescued from spam — it just won't
send replies back.

Use 2-3 receiving mailboxes rather than one, so volume doesn't all pile
into a single personal inbox. A Gmail filter that labels/archives mail
from the warmer sender address keeps it out of your way.

Make sure SPF, DKIM, and DMARC are configured for your Mailgun sending
domain before warming — reputation is tied to the domain, and warming on
top of a broken DNS setup won't help.

### Getting app passwords
- **Gmail / Google Workspace**: enable 2FA, then create an App Password
  (Account → Security → App passwords). Don't use your normal password.
- **Microsoft 365 / Outlook**: same idea — generate an app password if
  security defaults require it, or use a dedicated SMTP-auth account.
- **Your own domain's mail server**: use the regular mailbox credentials
  for that account.

### Test it manually first

```bash
python warmer.py --status
python warmer.py --run        # one manual pass
python warmer.py --status     # confirm it sent / didn't send as expected
tail -f warmer.log
```

### Schedule it with cron

```bash
crontab -e
```

Add (runs every 20 minutes):

```
*/20 * * * * cd /opt/email_warmer && /opt/email_warmer/venv/bin/python warmer.py --run >> cron.log 2>&1
```

## Tuning the ramp

All in `config.yaml` under `settings`:

| Setting | What it does |
|---|---|
| `start_date` | Day 0 of the ramp. Set once, leave alone. |
| `base_daily_volume` | Emails/day per account on day 0. Start at 2-5. |
| `daily_increment` | How much the per-account target grows each day. |
| `max_daily_volume` | Hard cap per account per day. |
| `business_hour_start/end` | Only send inside this local window. |
| `reply_probability` | Chance an incoming warmer email gets a reply. |
| `spam_folders` | Folder names to check and rescue pool mail from. |

A sane starting curve: `base_daily_volume: 3`, `daily_increment: 1`,
`max_daily_volume: 25` — gets you to a solid daily volume over ~3-4 weeks,
which is the normal timeline deliverability providers expect.

## Notes / limits

- Only ever list mailboxes you own or are explicitly authorized to use —
  this is for warming your own sending infrastructure, not for sending to
  third parties.
- `state.json` tracks daily counters per account; delete the day's entry
  (or use `--reset-today`) if you need to replay a day for testing.
- IMAP `IDLE` isn't used — the script does periodic polls via cron instead,
  which is simpler to run reliably on a small VPS.
- If a provider rate-limits or flags an account, back off the ramp
  (lower `max_daily_volume`, increase `daily_increment` interval) rather
  than pushing through it.
